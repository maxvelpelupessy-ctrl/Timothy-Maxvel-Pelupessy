
import React, { useCallback } from 'react';
import { Page } from '../types';
import { DashboardIcon, MotorIcon, RentalIcon, MaintenanceIcon, CustomerIcon, AccountingIcon } from './icons/Icons';

interface SidebarProps {
  currentPage: Page;
  onPageChange: (page: Page) => void;
  isOpen: boolean;
  setOpen: React.Dispatch<React.SetStateAction<boolean>>;
}

const Sidebar: React.FC<SidebarProps> = ({ currentPage, onPageChange, isOpen, setOpen }) => {
  const NavItem = useCallback(<T extends Page,>({ page, label, icon: Icon }: { page: T, label: string, icon: React.FC<{className?: string}> }) => (
    <li
      className={`flex items-center p-3 my-1 rounded-lg cursor-pointer transition-colors duration-200 ${
        currentPage === page
          ? 'bg-blue-600 text-white shadow-md'
          : 'text-gray-600 hover:bg-blue-100 hover:text-blue-700'
      }`}
      onClick={() => onPageChange(page)}
    >
      <Icon className="w-6 h-6" />
      <span className="ml-4 font-medium">
        {label}
      </span>
    </li>
  ), [currentPage, onPageChange]);

  return (
    <>
        <div className={`fixed inset-0 bg-black bg-opacity-50 z-20 md:hidden ${isOpen ? 'block' : 'hidden'}`} onClick={() => setOpen(false)}></div>
        <div
            className={`bg-white text-gray-800 w-64 space-y-6 py-7 px-2 fixed inset-y-0 left-0 transform ${isOpen ? 'translate-x-0' : '-translate-x-full'} md:relative md:translate-x-0 transition-transform duration-300 ease-in-out z-30 shadow-lg md:shadow-none`}
        >
            <div className="px-4 mb-10">
                <h2 className="text-2xl font-bold text-blue-700">RentalMotor ERP</h2>
                <p className="text-sm text-gray-500">Manajemen Rental Anda</p>
            </div>
            <nav>
                <ul>
                    <NavItem page="dashboard" label="Dashboard" icon={DashboardIcon} />
                    <NavItem page="motors" label="Data Motor" icon={MotorIcon} />
                    <NavItem page="rentals" label="Transaksi Sewa" icon={RentalIcon} />
                    <NavItem page="maintenance" label="Perawatan" icon={MaintenanceIcon} />
                    <NavItem page="customers" label="Pelanggan" icon={CustomerIcon} />
                    <NavItem page="accounting" label="Akuntansi" icon={AccountingIcon} />
                </ul>
            </nav>
        </div>
    </>
  );
};

export default Sidebar;
