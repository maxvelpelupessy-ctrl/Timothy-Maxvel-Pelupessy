
import React, { useMemo } from 'react';
import { ResponsiveContainer, PieChart, Pie, Cell, Legend, Tooltip } from 'recharts';
import { MotorStatus } from '../types';
import Card from './Card';
import { INITIAL_MOTORS } from '../constants'; // Using mock data for now
import { MotorIcon, CheckCircleIcon, ClockIcon, WrenchIcon } from './icons/Icons';

const Dashboard: React.FC = () => {
    // In a real app, this data would come from a hook like React Query
    const motors = INITIAL_MOTORS;

    const stats = useMemo(() => {
        const total = motors.length;
        const available = motors.filter(m => m.status === MotorStatus.AVAILABLE).length;
        const rented = motors.filter(m => m.status === MotorStatus.RENTED).length;
        const maintenance = motors.filter(m => m.status === MotorStatus.MAINTENANCE).length;
        return { total, available, rented, maintenance };
    }, [motors]);

    const chartData = [
        { name: 'Available', value: stats.available },
        { name: 'Rented', value: stats.rented },
        { name: 'Maintenance', value: stats.maintenance },
    ];

    const COLORS = ['#10B981', '#F59E0B', '#EF4444'];

    return (
        <div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <Card title="Total Motor" value={stats.total.toString()} icon={<MotorIcon className="h-8 w-8 text-blue-500" />} />
                <Card title="Tersedia" value={stats.available.toString()} icon={<CheckCircleIcon className="h-8 w-8 text-green-500" />} />
                <Card title="Disewa" value={stats.rented.toString()} icon={<ClockIcon className="h-8 w-8 text-yellow-500" />} />
                <Card title="Perawatan" value={stats.maintenance.toString()} icon={<WrenchIcon className="h-8 w-8 text-red-500" />} />
            </div>

            <div className="bg-white p-6 rounded-xl shadow-lg">
                <h3 className="text-xl font-semibold text-gray-700 mb-4">Distribusi Status Armada</h3>
                <div style={{ width: '100%', height: 300 }}>
                    <ResponsiveContainer>
                        <PieChart>
                            <Pie
                                data={chartData}
                                cx="50%"
                                cy="50%"
                                labelLine={false}
                                outerRadius={100}
                                fill="#8884d8"
                                dataKey="value"
                                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                            >
                                {chartData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                            </Pie>
                            <Tooltip formatter={(value) => `${value} unit`} />
                            <Legend />
                        </PieChart>
                    </ResponsiveContainer>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
