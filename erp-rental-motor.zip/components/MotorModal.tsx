
import React, { useState, useCallback } from 'react';
import { Motor, MotorStatus, Price } from '../types';

interface MotorModalProps {
  motor: Motor | null;
  onSave: (motor: Motor) => void;
  onClose: () => void;
}

const MotorModal: React.FC<MotorModalProps> = ({ motor, onSave, onClose }) => {
  const [formData, setFormData] = useState<Omit<Motor, 'id' | 'imageUrl'>>({
    name: motor?.name || '',
    brand: motor?.brand || '',
    model: motor?.model || '',
    year: motor?.year || new Date().getFullYear(),
    plateNumber: motor?.plateNumber || '',
    status: motor?.status || MotorStatus.AVAILABLE,
    price: motor?.price || { daily: 0, weekly: 0, monthly: 0 },
  });

  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: name === 'year' ? parseInt(value) : value }));
  }, []);
  
  const handlePriceChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, price: { ...prev.price, [name]: parseInt(value) || 0 } }));
  }, []);

  const handleSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    const motorToSave: Motor = {
        ...formData,
        id: motor?.id || '',
        imageUrl: motor?.imageUrl || `https://picsum.photos/seed/${formData.plateNumber}/300/200`
    }
    onSave(motorToSave);
  }, [formData, motor, onSave]);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex justify-center items-center">
      <div className="bg-white rounded-lg shadow-2xl p-8 w-full max-w-lg m-4 max-h-screen overflow-y-auto">
        <h2 className="text-2xl font-bold mb-6 text-gray-800">{motor ? 'Edit Motor' : 'Tambah Motor Baru'}</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <InputField label="Nama Motor" name="name" value={formData.name} onChange={handleChange} required />
            <InputField label="Brand" name="brand" value={formData.brand} onChange={handleChange} required />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <InputField label="Model" name="model" value={formData.model} onChange={handleChange} />
            <InputField label="Tahun" name="year" type="number" value={formData.year} onChange={handleChange} required />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <InputField label="No. Polisi" name="plateNumber" value={formData.plateNumber} onChange={handleChange} required />
             <div>
                <label className="block text-sm font-medium text-gray-700">Status</label>
                <select name="status" value={formData.status} onChange={handleChange} className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    {Object.values(MotorStatus).map(status => (
                        <option key={status} value={status}>{status}</option>
                    ))}
                </select>
             </div>
          </div>
          <fieldset className="border p-4 rounded-md">
            <legend className="text-sm font-medium text-gray-700 px-2">Harga Sewa (IDR)</legend>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-2">
                <InputField label="Harian" name="daily" type="number" value={formData.price.daily} onChange={handlePriceChange} />
                <InputField label="Mingguan" name="weekly" type="number" value={formData.price.weekly} onChange={handlePriceChange} />
                <InputField label="Bulanan" name="monthly" type="number" value={formData.price.monthly} onChange={handlePriceChange} />
            </div>
          </fieldset>
          
          <div className="flex justify-end pt-4 space-x-2">
            <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">Batal</button>
            <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Simpan</button>
          </div>
        </form>
      </div>
    </div>
  );
};

const InputField: React.FC<{label: string, name: string, value: string | number, onChange: (e: React.ChangeEvent<HTMLInputElement>) => void, type?: string, required?: boolean}> = ({ label, name, value, onChange, type = 'text', required = false }) => {
    return (
        <div>
            <label htmlFor={name} className="block text-sm font-medium text-gray-700">{label}</label>
            <input
                type={type}
                id={name}
                name={name}
                value={value}
                onChange={onChange}
                required={required}
                className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            />
        </div>
    );
};

export default MotorModal;
