
import React from 'react';
import { MenuIcon, UserCircleIcon, BellIcon } from './icons/Icons';

interface HeaderProps {
  title: string;
  onMenuClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ title, onMenuClick }) => {
  return (
    <header className="bg-white shadow-sm z-10">
      <div className="flex items-center justify-between h-16 px-6">
        <div className="flex items-center">
            <button
                className="text-gray-500 focus:outline-none md:hidden"
                onClick={onMenuClick}
                aria-label="Open sidebar"
            >
                <MenuIcon className="h-6 w-6" />
            </button>
            <h1 className="text-xl font-semibold text-gray-700 ml-2 md:ml-0">{title}</h1>
        </div>

        <div className="flex items-center space-x-4">
            <button className="p-2 text-gray-500 rounded-full hover:bg-gray-100 focus:outline-none focus:bg-gray-100">
                <BellIcon className="h-6 w-6" />
            </button>
            <div className="flex items-center">
                <span className="text-right mr-3 hidden sm:block">
                    <p className="font-semibold">Admin</p>
                    <p className="text-xs text-gray-500">Super Admin</p>
                </span>
                <button className="p-2 text-gray-500 rounded-full hover:bg-gray-100 focus:outline-none focus:bg-gray-100">
                    <UserCircleIcon className="h-8 w-8"/>
                </button>
            </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
