
import React, { useState, useCallback, useMemo } from 'react';
import { Motor, MotorStatus } from '../types';
import { INITIAL_MOTORS } from '../constants';
import MotorModal from './MotorModal';
import { PencilIcon, TrashIcon, PlusIcon } from './icons/Icons';

const getStatusBadge = (status: MotorStatus) => {
  switch (status) {
    case MotorStatus.AVAILABLE:
      return 'bg-green-100 text-green-800';
    case MotorStatus.RENTED:
      return 'bg-yellow-100 text-yellow-800';
    case MotorStatus.MAINTENANCE:
      return 'bg-red-100 text-red-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

const MotorList: React.FC = () => {
  const [motors, setMotors] = useState<Motor[]>(INITIAL_MOTORS);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingMotor, setEditingMotor] = useState<Motor | null>(null);

  const openAddModal = useCallback(() => {
    setEditingMotor(null);
    setIsModalOpen(true);
  }, []);

  const openEditModal = useCallback((motor: Motor) => {
    setEditingMotor(motor);
    setIsModalOpen(true);
  }, []);

  const closeModal = useCallback(() => {
    setIsModalOpen(false);
    setEditingMotor(null);
  }, []);

  const handleSave = useCallback((motor: Motor) => {
    if (editingMotor) {
      setMotors(prevMotors => prevMotors.map(m => m.id === motor.id ? motor : m));
    } else {
      setMotors(prevMotors => [...prevMotors, { ...motor, id: new Date().toISOString() }]);
    }
    closeModal();
  }, [editingMotor, closeModal]);

  const handleDelete = useCallback((motorId: string) => {
    if(window.confirm('Are you sure you want to delete this motor?')) {
        setMotors(prevMotors => prevMotors.filter(m => m.id !== motorId));
    }
  }, []);

  const formattedMotors = useMemo(() => motors.map(motor => ({
    ...motor,
    priceFormatted: new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(motor.price.daily)
  })), [motors]);

  return (
    <>
      <div className="bg-white p-6 rounded-xl shadow-lg">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-semibold text-gray-700">Daftar Motor</h3>
          <button
            onClick={openAddModal}
            className="flex items-center bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition-colors"
          >
            <PlusIcon className="w-5 h-5 mr-2" />
            Tambah Motor
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Motor</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">No. Polisi</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Harga/Hari</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {formattedMotors.map((motor) => (
                <tr key={motor.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10">
                            <img className="h-10 w-10 rounded-full object-cover" src={motor.imageUrl} alt={motor.name} />
                        </div>
                        <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">{motor.name}</div>
                            <div className="text-sm text-gray-500">{motor.brand} {motor.year}</div>
                        </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{motor.plateNumber}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-semibold">{motor.priceFormatted}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadge(motor.status)}`}>
                      {motor.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button onClick={() => openEditModal(motor)} className="text-indigo-600 hover:text-indigo-900 mr-4">
                        <PencilIcon className="w-5 h-5"/>
                    </button>
                    <button onClick={() => handleDelete(motor.id)} className="text-red-600 hover:text-red-900">
                        <TrashIcon className="w-5 h-5"/>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      {isModalOpen && <MotorModal motor={editingMotor} onSave={handleSave} onClose={closeModal} />}
    </>
  );
};

export default MotorList;
