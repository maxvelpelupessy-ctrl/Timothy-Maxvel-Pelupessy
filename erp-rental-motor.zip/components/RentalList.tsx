import React, { useState, useCallback, useRef } from 'react';
import { Rental, RentalStatus } from '../types';
import { INITIAL_RENTALS } from '../constants';
import { UploadIcon } from './icons/Icons';

const getRentalStatusBadge = (status: RentalStatus) => {
  switch (status) {
    case RentalStatus.ONGOING:
    case RentalStatus.RENTED:
      return 'bg-blue-100 text-blue-800';
    case RentalStatus.COMPLETED:
      return 'bg-green-100 text-green-800';
    case RentalStatus.UPCOMING:
      return 'bg-yellow-100 text-yellow-800';
    case RentalStatus.AVAILABLE:
      return 'bg-gray-100 text-gray-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

const RentalList: React.FC = () => {
  const [rentals, setRentals] = useState<Rental[]>(INITIAL_RENTALS);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImportClick = useCallback(() => {
    fileInputRef.current?.click();
  }, []);

  const handleFileChange = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result as string;
        const lines = text.split(/\r?\n/).filter(line => line.trim() !== '');
        if (lines.length <= 1) {
            throw new Error("CSV file is empty or contains only a header.");
        }
        
        const headerLine = lines.shift()?.trim() || '';
        const rawHeaders = headerLine.split(',').map(h => h.trim().replace(/^"|"$/g, ''));
        
        const normalizeHeader = (h: string) => h.toLowerCase().replace(/[^a-z0-9]/g, '');
        const normalizedHeaders = rawHeaders.map(normalizeHeader);

        const headerMapping: { [key in keyof Required<Rental>]: string[] } = {
            id: [''],
            no: ['no'],
            customerName: ['customername'],
            customerPhone: ['notelp'],
            motorId: ['motorid'],
            motorName: ['motorname'],
            rentalDurationDays: ['lamarentalhari'],
            startDate: ['startdate'],
            endDate: ['enddate'],
            totalPrice: ['totalpricerp', 'totalprice'],
            status: ['status'],
        };
        
        const requiredFields: (keyof Rental)[] = ['customerName', 'motorId', 'motorName', 'startDate', 'endDate', 'totalPrice', 'status'];
        const indexMap = new Map<keyof Rental, number>();
        
        for (const key in headerMapping) {
            const propKey = key as keyof Rental;
            const possibleHeaders = headerMapping[propKey];
            for (const pHeader of possibleHeaders) {
                const foundIndex = normalizedHeaders.indexOf(pHeader);
                if (foundIndex !== -1) {
                    indexMap.set(propKey, foundIndex);
                    break;
                }
            }
        }
        
        const missingHeaders = requiredFields.filter(f => !indexMap.has(f));
        if (missingHeaders.length > 0) {
            throw new Error(`Invalid CSV header. Missing columns: ${missingHeaders.join(', ')}`);
        }

        const newRentals: Rental[] = lines.map((line, index) => {
          const values = line.trim().split(',').map(v => v.trim().replace(/^"|"$/g, ''));
          
          const getColumn = (name: keyof Rental): string | undefined => {
              const idx = indexMap.get(name);
              return idx !== undefined ? values[idx] : undefined;
          };
          
          const statusValue = getColumn('status') as RentalStatus;
          if (!statusValue || !Object.values(RentalStatus).includes(statusValue)) {
              throw new Error(`Invalid or missing status on row ${index + 2}: ${getColumn('status')}`);
          }

          const getNumericColumn = (name: keyof Rental): number | undefined => {
              const val = getColumn(name);
              if (val === undefined || val === '') return undefined;
              const parsed = parseInt(val, 10);
              if (isNaN(parsed)) throw new Error(`Invalid number format for ${name} on row ${index + 2}: ${val}`);
              return parsed;
          }

          const totalPrice = getNumericColumn('totalPrice');
          if (totalPrice === undefined) {
             throw new Error(`Missing totalPrice on row ${index + 2}`);
          }

          return {
            id: `CSV-${new Date().getTime()}-${index}`,
            no: getNumericColumn('no'),
            customerName: getColumn('customerName') ?? `Unknown Customer ${index}`,
            customerPhone: getColumn('customerPhone'),
            motorId: getColumn('motorId') ?? `Unknown MotorID ${index}`,
            motorName: getColumn('motorName') ?? `Unknown Motor ${index}`,
            rentalDurationDays: getNumericColumn('rentalDurationDays'),
            startDate: getColumn('startDate') ?? '',
            endDate: getColumn('endDate') ?? '',
            totalPrice: totalPrice,
            status: statusValue,
          };
        });

        setRentals(prev => [...prev, ...newRentals]);
        alert(`${newRentals.length} transactions imported successfully!`);
      } catch (error) {
        console.error("CSV parsing error:", error);
        alert(`Error importing CSV: ${error instanceof Error ? error.message : 'Unknown error'}`);
      } finally {
        if (event.target) {
            event.target.value = '';
        }
      }
    };
    reader.readAsText(file);
  }, []);
  
  const formatDate = (dateString: string) => {
      if (!dateString) return 'N/A';
      try {
        const date = new Date(dateString);
        if (isNaN(date.getTime())) {
            return "Invalid Date";
        }
        return date.toLocaleDateString('id-ID', {
            day: '2-digit', month: '2-digit', year: 'numeric'
        }).replace(/\//g, '-');
      } catch (error) {
        return "Invalid Date";
      }
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-lg">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-xl font-semibold text-gray-700">Daftar Transaksi Sewa</h3>
        <button
          onClick={handleImportClick}
          className="flex items-center bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-opacity-50 transition-colors"
          aria-label="Import transactions from CSV file"
        >
          <UploadIcon className="w-5 h-5 mr-2" />
          Import from CSV
        </button>
        <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".csv,text/csv"
            className="hidden"
            aria-hidden="true"
        />
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">No.</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer Name</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">No. Telp</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Motor ID</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Motor Name</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Lama Rental (Hari)</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Price (Rp)</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Start Date</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">End Date</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {rentals.map((rental) => (
              <tr key={rental.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{rental.no ?? 'N/A'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{rental.customerName}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{rental.customerPhone ?? 'N/A'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{rental.motorId}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{rental.motorName}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">{rental.rentalDurationDays ?? 'N/A'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-semibold">
                  {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(rental.totalPrice)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{rental.startDate}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{rental.endDate}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getRentalStatusBadge(rental.status)}`}>
                    {rental.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default RentalList;